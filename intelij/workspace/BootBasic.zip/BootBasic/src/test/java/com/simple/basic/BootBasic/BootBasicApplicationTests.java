package com.simple.basic.BootBasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
